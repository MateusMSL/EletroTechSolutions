/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;


public class Conexao {
 
 private static final String USERNAME = "root";
 
 private static final String PASSWORD = "";
 
 private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/eletrotech_solutions";
 
 public static Connection createConnectionToMysql() throws Exception {
     
 Class.forName("com.mysql.cj.jdbc.Driver");
 
 Connection connection = DriverManager.getConnection(DATABASE_URL,USERNAME,PASSWORD);
 
    return connection;
 }   
 
    public static void main(String[] args) throws Exception {
        
    Connection con = createConnectionToMysql();

    if(con != null){
        System.out.println("Conexão estabelecida com sucesso!!");
        con.close();
    } else {System.out.println("Falha na Conexão!");
    
    }
        
        
    }
}
