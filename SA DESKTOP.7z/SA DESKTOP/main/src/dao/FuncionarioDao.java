/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import database.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Cliente;
import model.Funcionario;

public class FuncionarioDao {
 
    public void criar(Funcionario funcionario){
        
        String sql = "INSERT INTO funcionario(Nome,Email,Telefone,CPF,Senha,Status) VALUES (?,?,?,?,?,?)";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
            conn = Conexao.createConnectionToMysql();
            
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            
            pstm.setString(1,funcionario.getNome());
            pstm.setString(2, funcionario.getEmail());
            pstm.setString(3, funcionario.getTelefone());
            pstm.setString(4,funcionario.getCpf());
            pstm.setString(5,funcionario.getSenha());
            pstm.setString(6,funcionario.getStatus());
            
            pstm.execute();
            
            System.out.println("Funcionario Cadastrado com sucesso!!");
        } catch(Exception e) {
            
            System.out.println("Não foi possível realizar o cadastro!");
            e.printStackTrace();
        } finally {
            
            try {
                if (pstm != null) {pstm.close();}
                if(conn != null) {conn.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    
    public List<Funcionario> PuxaEmail(String email) {
        
        String sql = "SELECT * FROM funcionario WHERE Email = ? ";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        //Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        try {
        conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
        
        
        pstm.setString(1,email);
        pstm.execute();
        rset = pstm.executeQuery();
        
        while(rset.next()){
            
            Funcionario funcionario = new Funcionario();
            //Recuperar dados de cada coluna no banco de dados
            funcionario.setEmail(rset.getString("Email"));
       
            funcionarios.add(funcionario);
        }
           
            
        
        }catch(Exception e) {
            JOptionPane.showMessageDialog(null,"Não foi possível acessar o email no banco de dados");
            e.printStackTrace();
        } finally {
            try {
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
            }
            return funcionarios;
        }
    
    
    
        public List<Funcionario> PuxaSenha(String senha) {
        
        String sql = "SELECT * FROM funcionario WHERE Senha = ? ";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        //Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        try {
        conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
        
        
        pstm.setString(1,senha);
        pstm.execute();
        rset = pstm.executeQuery();
        
        while(rset.next()){
            
            Funcionario funcionario = new Funcionario();
            //Recuperar dados de cada coluna no banco de dados
            funcionario.setSenha(rset.getString("Senha"));
       
            funcionarios.add(funcionario);
        }
            
            
        
        }catch(Exception e) {
            JOptionPane.showMessageDialog(null,"Não foi possível acessar a senha no banco de dados");
            e.printStackTrace();
        } finally {
            try {
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
            }
            return funcionarios;
        }
        
        
        public List<Funcionario> PuxaCpf(String cpf) {
        
        String sql = "SELECT * FROM funcionario WHERE Cpf = ? ";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        //Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        try {
        conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
        
        
        pstm.setString(1,cpf);
        pstm.execute();
        rset = pstm.executeQuery();
        
        while(rset.next()){
            
            Funcionario funcionario = new Funcionario();
            //Recuperar dados de cada coluna no banco de dados
            funcionario.setCpf(rset.getString("Cpf"));
       
            funcionarios.add(funcionario);
        }
        
        }catch(Exception e) {
            JOptionPane.showMessageDialog(null,"Não foi possível acessar o cpf no banco de dados");
            e.printStackTrace();
        } finally {
            try {
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
            }
            return funcionarios;
        }
    
        
        
        public List<Funcionario> PuxaNomePorEmail(String email) {
        
        String sql = "SELECT * FROM funcionario WHERE email = ? ";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        //Classe que vai recuperar os dados do banco
        ResultSet rset = null;
        try {
        conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
        
        
        pstm.setString(1,email);
        pstm.execute();
        rset = pstm.executeQuery();
        
        while(rset.next()){
            
            Funcionario funcionario = new Funcionario();
            //Recuperar dados de cada coluna no banco de dados
            funcionario.setNome(rset.getString("Nome"));
       
            funcionarios.add(funcionario);
        }
            
            
        
        }catch(Exception e) {
            JOptionPane.showMessageDialog(null,"Não foi possível acessar o nome no banco de dados");
            e.printStackTrace();
        } finally {
            try {
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
            }
            return funcionarios;
        }
        

        public List<Funcionario> ListarUmFuncionario(int id){
        
        String sql ="SELECT * FROM funcionario WHERE idFuncionario = ?";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;
        try {
            conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
        
        rset = pstm.executeQuery();
        
        while (rset.next()){
            Funcionario funcionario = new Funcionario();
            
            funcionario.setId(rset.getInt("idFuncionario"));
            funcionario.setNome(rset.getString("Nome"));
            funcionario.setEmail(rset.getString("Email"));
            funcionario.setTelefone(rset.getString("Telefone"));
            funcionario.setCpf(rset.getString("CPF"));
            funcionario.setSenha(rset.getString("Senha"));
            funcionario.setStatus(rset.getString("Status"));
        
          funcionarios.add(funcionario);
        }
            System.out.println("Funcionario listado com sucesos!");
        } catch (Exception e) {
            System.out.println("Erro ao listar o funcionario!!");
          e.printStackTrace();
        } finally {
            try{
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return funcionarios;
    }
        
        
        
        
    public List<Funcionario> ListarFuncionarios(){
        
        String sql ="SELECT * FROM funcionario";
        
        List<Funcionario> funcionarios = new ArrayList<Funcionario>();
        
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;
        try {
            conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
        
        rset = pstm.executeQuery();
        
        while (rset.next()){
            Funcionario funcionario = new Funcionario();
            
            funcionario.setId(rset.getInt("idFuncionario"));
            funcionario.setNome(rset.getString("Nome"));
            funcionario.setEmail(rset.getString("Email"));
            funcionario.setTelefone(rset.getString("Telefone"));
            funcionario.setCpf(rset.getString("CPF"));
            funcionario.setSenha(rset.getString("Senha"));
            funcionario.setStatus(rset.getString("Status"));
        
          funcionarios.add(funcionario);
        }
            System.out.println("Funcionarios listados com sucesos!");
        } catch (Exception e) {
            System.out.println("Erro ao listar os funcionarios!!");
          e.printStackTrace();
        } finally {
            try{
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return funcionarios;
    }
    
    
    
    public void alterar(Funcionario funcionario){
        String sql = "UPDATE funcionario SET Nome=?, Email = ?, Telefone = ?, CPF = ?, Senha = ?, Status = ? WHERE idFuncionario = ?";
        
         Connection conn = null;
            PreparedStatement pstm = null;
            
            try {
                conn = Conexao.createConnectionToMysql();
                pstm = (PreparedStatement) conn.prepareStatement(sql);
                
           pstm.setString(1,funcionario.getNome());
            pstm.setString(2,funcionario.getEmail());
            pstm.setString(3,funcionario.getTelefone());
            pstm.setString(4,funcionario.getCpf());
            pstm.setString(5,funcionario.getSenha());
            pstm.setString(6,funcionario.getStatus());
            
            pstm.setInt(7, funcionario.getId());
            
            pstm.execute();
            
            } catch (Exception e) {
                
                System.out.println("Erro ao tentar alterar os dados do funcionário!");
                e.printStackTrace();
            } finally {
                try{
                    if(pstm!=null) {pstm.close();}
                    if(pstm!=null){pstm.close();}
                    
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
    }
    
    
    public void excluir (int id){
        String sql = "DELETE FROM funcionario WHERE idFuncionario = ?";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
             conn = Conexao.createConnectionToMysql();
                pstm = (PreparedStatement) conn.prepareStatement(sql);
                
                pstm.setInt(1,id);
                pstm.execute();
                
                JOptionPane.showMessageDialog(null,"Funcionário Excluído com sucesso!");
                
         } catch (Exception e) {
            
                System.out.println("Erro ao tentar excluir o veículo");
                e.printStackTrace();
                
            } finally {
                
                try {
                    
                    if(pstm!= null) {pstm.close();}
                    if(conn != null){conn.close();}
                } catch (Exception e) {
                
                e.printStackTrace();
                
                }
        }
    }
}
            
    
        
    

