package dao;

import database.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Agendamento;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class AgendamentoDao {

    
    void criar(Agendamento agendamento){
    String sql = "INSERT INTO agendamento(idCliente, idFuncionario,Rua,Numero,Bairro,Cidade,Tipo,Complemento,Data,Horario) VALUES (?,?,?,?,?,?,?,?,?,?)";
    
    Connection conn = null;
    PreparedStatement pstm = null;
           
        try {
            conn = Conexao.createConnectionToMysql();
        
            
            pstm = (PreparedStatement) conn.prepareStatement(sql);
           
            pstm.setInt(1,agendamento.getIdCliente());
            pstm.setInt(2,agendamento.getIdFuncionario());
            pstm.setString(3,agendamento.getRua());
            pstm.setString(4, agendamento.getNumero());
            pstm.setString(5,agendamento.getBairro());
            pstm.setString(6,agendamento.getCidade());
            pstm.setString(7,agendamento.getTipo());
            pstm.setString(8,agendamento.getComplemento());
            pstm.setString(9, agendamento.getData());
            pstm.setString(10, agendamento.getHorario());
            
            pstm.execute();
            
            System.out.println("Agendamento cadastrado com sucesso!!");
            
        } catch (Exception e) {
    
            System.out.println("O agendamento não foi realizado!!");
            e.printStackTrace();
            
    
        } finally {
    
     try {
                if(pstm != null){ pstm.close();}
                if(conn != null) {conn.close(); }
            } catch (Exception e){
                e.printStackTrace();
                
            }
    
}
    }
    
    public List<Agendamento> listarAgendamentos(){
        
        String sql = "SELECT * FROM agendamento";
        
        List<Agendamento> agendamentos = new ArrayList<Agendamento>();
        
          Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rset = null;
        try {
            conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
        
        rset = pstm.executeQuery();
        
        while (rset.next()) {
            Agendamento agendamento = new Agendamento();
            
            agendamento.setId(rset.getInt("idAgendamento"));
            agendamento.setIdCliente(rset.getInt("idCliente"));
            agendamento.setIdFuncionario(rset.getInt("idFuncionario"));
            agendamento.setRua(rset.getString("Rua"));
            agendamento.setNumero(rset.getString("Numero"));
            agendamento.setBairro(rset.getString("Bairro"));
            agendamento.setCidade(rset.getString("Cidade"));
            agendamento.setTipo(rset.getString("Tipo"));
            agendamento.setComplemento(rset.getString("Complemento"));
            agendamento.setData(rset.getString("Data"));
            agendamento.setHorario(rset.getString("Horario"));
       
            agendamentos.add(agendamento);
        }
       System.out.println("agendamentos listados com sucesso!!");
        } catch (Exception e) {
            System.out.println("Erro ao listar todos os agendamentos");
            e.printStackTrace();
        } finally {
               try{
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return agendamentos; 
        }
    
    
        public void alterarFuncionario(int idF, int id){
        String sql = "UPDATE agendamento SET idFuncionario=? WHERE idAgendamento=?";
   
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
             conn = Conexao.createConnectionToMysql();
                pstm = (PreparedStatement) conn.prepareStatement(sql);
                
                pstm.setInt(1,idF);
                pstm.setInt(2,id);
                pstm.execute();
                
                System.out.println("Funcionario alterado com sucesso!");
                
        } catch (Exception e) {
            
            System.out.println("Erro ao tentar alterar o agendamento!!");
            e.printStackTrace();
        } finally {
              
                try {
                    
                    if(pstm!= null) {pstm.close();}
                    if(conn != null){conn.close();}
                } catch (Exception e) {
                
                e.printStackTrace();
                
                }
            
        }
    }
    
    
    
    public void alterar(Agendamento agendamento){
        String sql = "UPDATE agendamento SET Status=? WHERE idAgendamento=?";
    
        Connection conn = null;
            PreparedStatement pstm = null;
            
            try {
                conn = Conexao.createConnectionToMysql();
                pstm = (PreparedStatement) conn.prepareStatement(sql);
        
                pstm.setInt(1,agendamento.getIdCliente());
                pstm.setInt(2,agendamento.getIdFuncionario());
                pstm.setString(3,agendamento.getRua());
                pstm.setString(4, agendamento.getNumero());
                pstm.setString(5,agendamento.getBairro());
                pstm.setString(6,agendamento.getCidade());
                pstm.setString(7,agendamento.getTipo());
                pstm.setString(8,agendamento.getComplemento());
                pstm.setString(9,agendamento.getData());
                pstm.setString(10,agendamento.getHorario());
                
                pstm.setInt(11,agendamento.getId());
        
                pstm.execute();
    } catch (Exception e) {
                System.out.println("erro ao tentar alterar agendamento!!");
                e.printStackTrace();
    } finally {
                try{
                    if(pstm!=null) {pstm.close();}
                    if(pstm!=null){pstm.close();}
                    
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    
    public void excluir(int id){
        String sql = "DELETE FROM agendamento WHERE idAgendamento = ?";
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        try {
             conn = Conexao.createConnectionToMysql();
                pstm = (PreparedStatement) conn.prepareStatement(sql);
                
                pstm.setInt(1,id);
                pstm.execute();
                
                JOptionPane.showMessageDialog(null,"Agendamento Excluído com sucesso!");
                
        } catch (Exception e) {
            
            System.out.println("Erro ao tentar excluir o agendamento!!");
            e.printStackTrace();
        } finally {
              
                try {
                    
                    if(pstm!= null) {pstm.close();}
                    if(conn != null){conn.close();}
                } catch (Exception e) {
                
                e.printStackTrace();
                
                }
            
        }
    }
}
    
