/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import database.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.InnerJoinAll;


public class InnerJoinDao {
    
     public List<InnerJoinAll> ListarDados(){
        
        String sql ="SELECT a.idAgendamento, f.Nome, a.Status, c.Nome, a.Rua, a.Numero, a.Bairro,a.Cidade, a.Valor, a.Tipo FROM agendamento as a inner join funcionario as f inner join cliente as c WHERE a.idCliente = c.idCliente AND f.IdFuncionario = a.idFuncionario";
      
        List<InnerJoinAll> innerjoinalls = new ArrayList<InnerJoinAll>();
        
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        ResultSet rset = null;
        
        try {
            conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
       
        
        rset = pstm.executeQuery();
        

       
        
         while (rset.next()){
            InnerJoinAll innerjoinall = new InnerJoinAll();
            innerjoinall.setId(rset.getInt("a.idAgendamento"));
            innerjoinall.setNomeFuncionario(rset.getString("f.Nome"));
            innerjoinall.setStatus(rset.getString("a.Status"));
            innerjoinall.setNomeCliente(rset.getString("c.Nome"));
            innerjoinall.setRua(rset.getString("a.Rua"));
            innerjoinall.setNumero(rset.getString("a.Numero"));
            innerjoinall.setBairro(rset.getString("a.Bairro"));
            innerjoinall.setCidade(rset.getString("a.Cidade"));
            innerjoinall.setValor(rset.getDouble("a.Valor"));
            innerjoinall.setTipo(rset.getString("a.Tipo"));
          innerjoinalls.add(innerjoinall);
        }
        
            System.out.println("dados listados com sucesos!");
        } catch (Exception e) {
            System.out.println("Erro ao listar os dados!");
          e.printStackTrace();
        } finally {
            try{
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return innerjoinalls;
    }
    
     public List<InnerJoinAll> ListarOS(int id){
        
        String sql ="SELECT a.idAgendamento, c.Nome, a.Rua, a.Numero, a.Bairro,a.Cidade,  a.Tipo, a.Data, a.Horario, a.Valor FROM agendamento as a inner join funcionario as f inner join cliente as c WHERE a.idCliente = c.idCliente AND ? = a.idFuncionario";
      
        List<InnerJoinAll> innerjoinalls = new ArrayList<InnerJoinAll>();
        
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        ResultSet rset = null;
        
        try {
            conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
       
        
        rset = pstm.executeQuery();
        

       
        
         while (rset.next()){
            InnerJoinAll innerjoinall = new InnerJoinAll();
            innerjoinall.setId(rset.getInt("a.idAgendamento"));
            innerjoinall.setNomeFuncionario(rset.getString("f.Nome"));
            innerjoinall.setStatus(rset.getString("f.Status"));
            innerjoinall.setNomeCliente(rset.getString("c.Nome"));
            innerjoinall.setRua(rset.getString("a.Rua"));
            innerjoinall.setNumero(rset.getString("a.Numero"));
            innerjoinall.setBairro(rset.getString("a.Bairro"));
            innerjoinall.setCidade(rset.getString("a.Cidade"));
            innerjoinall.setHorario(rset.getString("a.Horario"));
            innerjoinall.setData(rset.getString("a.Data"));
            innerjoinall.setValor(rset.getDouble("a.Valor"));
            innerjoinall.setTipo(rset.getString("a.Tipo"));
          innerjoinalls.add(innerjoinall);
        }
        
            System.out.println("dados listados com sucesos!");
        } catch (Exception e) {
            System.out.println("Erro ao listar os dados!");
          e.printStackTrace();
        } finally {
            try{
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return innerjoinalls;
    }
    
         public List<InnerJoinAll> ListarCliente(){
        
        String sql ="SELECT c.Nome, c.Email, c.Telefone, c.Cpf FROM cliente as c";
      
        List<InnerJoinAll> innerjoinalls = new ArrayList<InnerJoinAll>();
        
        
        Connection conn = null;
        PreparedStatement pstm = null;
        
        ResultSet rset = null;
        
        try {
            conn = Conexao.createConnectionToMysql();
        pstm = (PreparedStatement) conn.prepareStatement(sql);
       
        
        rset = pstm.executeQuery();
        

       
        
         while (rset.next()){
            InnerJoinAll innerjoinall = new InnerJoinAll();
            innerjoinall.setNomeCliente(rset.getString("c.Nome"));
            innerjoinall.setEmail(rset.getString("c.Email"));
            innerjoinall.setTelefone(rset.getString("c.Telefone"));
            innerjoinall.setCpf(rset.getString("c.Cpf"));
      
          innerjoinalls.add(innerjoinall);
        }
        
            System.out.println("dados listados com sucesos!");
        } catch (Exception e) {
            System.out.println("Erro ao listar os dados!");
          e.printStackTrace();
        } finally {
            try{
                if(pstm != null){ pstm.close();}
                if(conn != null){conn.close();}
                if(rset != null) {rset.close();}
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return innerjoinalls;
    }
     
     
}
